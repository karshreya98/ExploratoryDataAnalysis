

```python
#import libraries
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
```


```python
#read the csv dataset
data=pd.read_csv('C:/Users/Shreya Kar/Desktop/Datasets/AB_NYC_2019.csv')
```


```python
data[:5]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>name</th>
      <th>host_id</th>
      <th>host_name</th>
      <th>neighbourhood_group</th>
      <th>neighbourhood</th>
      <th>latitude</th>
      <th>longitude</th>
      <th>room_type</th>
      <th>price</th>
      <th>minimum_nights</th>
      <th>number_of_reviews</th>
      <th>last_review</th>
      <th>reviews_per_month</th>
      <th>calculated_host_listings_count</th>
      <th>availability_365</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2539</td>
      <td>Clean &amp; quiet apt home by the park</td>
      <td>2787</td>
      <td>John</td>
      <td>Brooklyn</td>
      <td>Kensington</td>
      <td>40.64749</td>
      <td>-73.97237</td>
      <td>Private room</td>
      <td>149</td>
      <td>1</td>
      <td>9</td>
      <td>2018-10-19</td>
      <td>0.21</td>
      <td>6</td>
      <td>365</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2595</td>
      <td>Skylit Midtown Castle</td>
      <td>2845</td>
      <td>Jennifer</td>
      <td>Manhattan</td>
      <td>Midtown</td>
      <td>40.75362</td>
      <td>-73.98377</td>
      <td>Entire home/apt</td>
      <td>225</td>
      <td>1</td>
      <td>45</td>
      <td>2019-05-21</td>
      <td>0.38</td>
      <td>2</td>
      <td>355</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3647</td>
      <td>THE VILLAGE OF HARLEM....NEW YORK !</td>
      <td>4632</td>
      <td>Elisabeth</td>
      <td>Manhattan</td>
      <td>Harlem</td>
      <td>40.80902</td>
      <td>-73.94190</td>
      <td>Private room</td>
      <td>150</td>
      <td>3</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
      <td>365</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3831</td>
      <td>Cozy Entire Floor of Brownstone</td>
      <td>4869</td>
      <td>LisaRoxanne</td>
      <td>Brooklyn</td>
      <td>Clinton Hill</td>
      <td>40.68514</td>
      <td>-73.95976</td>
      <td>Entire home/apt</td>
      <td>89</td>
      <td>1</td>
      <td>270</td>
      <td>2019-07-05</td>
      <td>4.64</td>
      <td>1</td>
      <td>194</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5022</td>
      <td>Entire Apt: Spacious Studio/Loft by central park</td>
      <td>7192</td>
      <td>Laura</td>
      <td>Manhattan</td>
      <td>East Harlem</td>
      <td>40.79851</td>
      <td>-73.94399</td>
      <td>Entire home/apt</td>
      <td>80</td>
      <td>10</td>
      <td>9</td>
      <td>2018-11-19</td>
      <td>0.10</td>
      <td>1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
#descriptive stats of the dataset
data.describe(include='all')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>name</th>
      <th>host_id</th>
      <th>host_name</th>
      <th>neighbourhood_group</th>
      <th>neighbourhood</th>
      <th>latitude</th>
      <th>longitude</th>
      <th>room_type</th>
      <th>price</th>
      <th>minimum_nights</th>
      <th>number_of_reviews</th>
      <th>last_review</th>
      <th>reviews_per_month</th>
      <th>calculated_host_listings_count</th>
      <th>availability_365</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>4.889500e+04</td>
      <td>48879</td>
      <td>4.889500e+04</td>
      <td>48874</td>
      <td>48895</td>
      <td>48895</td>
      <td>48895.000000</td>
      <td>48895.000000</td>
      <td>48895</td>
      <td>48895.000000</td>
      <td>48895.000000</td>
      <td>48895.000000</td>
      <td>38843</td>
      <td>38843.000000</td>
      <td>48895.000000</td>
      <td>48895.000000</td>
    </tr>
    <tr>
      <th>unique</th>
      <td>NaN</td>
      <td>47905</td>
      <td>NaN</td>
      <td>11452</td>
      <td>5</td>
      <td>221</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>3</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1764</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>top</th>
      <td>NaN</td>
      <td>Hillside Hotel</td>
      <td>NaN</td>
      <td>Michael</td>
      <td>Manhattan</td>
      <td>Williamsburg</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Entire home/apt</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2019-06-23</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>freq</th>
      <td>NaN</td>
      <td>18</td>
      <td>NaN</td>
      <td>417</td>
      <td>21661</td>
      <td>3920</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>25409</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1413</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>1.901714e+07</td>
      <td>NaN</td>
      <td>6.762001e+07</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>40.728949</td>
      <td>-73.952170</td>
      <td>NaN</td>
      <td>152.720687</td>
      <td>7.029962</td>
      <td>23.274466</td>
      <td>NaN</td>
      <td>1.373221</td>
      <td>7.143982</td>
      <td>112.781327</td>
    </tr>
    <tr>
      <th>std</th>
      <td>1.098311e+07</td>
      <td>NaN</td>
      <td>7.861097e+07</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.054530</td>
      <td>0.046157</td>
      <td>NaN</td>
      <td>240.154170</td>
      <td>20.510550</td>
      <td>44.550582</td>
      <td>NaN</td>
      <td>1.680442</td>
      <td>32.952519</td>
      <td>131.622289</td>
    </tr>
    <tr>
      <th>min</th>
      <td>2.539000e+03</td>
      <td>NaN</td>
      <td>2.438000e+03</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>40.499790</td>
      <td>-74.244420</td>
      <td>NaN</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>NaN</td>
      <td>0.010000</td>
      <td>1.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>9.471945e+06</td>
      <td>NaN</td>
      <td>7.822033e+06</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>40.690100</td>
      <td>-73.983070</td>
      <td>NaN</td>
      <td>69.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>NaN</td>
      <td>0.190000</td>
      <td>1.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>1.967728e+07</td>
      <td>NaN</td>
      <td>3.079382e+07</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>40.723070</td>
      <td>-73.955680</td>
      <td>NaN</td>
      <td>106.000000</td>
      <td>3.000000</td>
      <td>5.000000</td>
      <td>NaN</td>
      <td>0.720000</td>
      <td>1.000000</td>
      <td>45.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>2.915218e+07</td>
      <td>NaN</td>
      <td>1.074344e+08</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>40.763115</td>
      <td>-73.936275</td>
      <td>NaN</td>
      <td>175.000000</td>
      <td>5.000000</td>
      <td>24.000000</td>
      <td>NaN</td>
      <td>2.020000</td>
      <td>2.000000</td>
      <td>227.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>3.648724e+07</td>
      <td>NaN</td>
      <td>2.743213e+08</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>40.913060</td>
      <td>-73.712990</td>
      <td>NaN</td>
      <td>10000.000000</td>
      <td>1250.000000</td>
      <td>629.000000</td>
      <td>NaN</td>
      <td>58.500000</td>
      <td>327.000000</td>
      <td>365.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
#shape of the dataset
data.shape
```




    (48895, 16)




```python
#analyze different columns
total=len(data.columns)
numerical= list(data.select_dtypes(include=np.number).columns)
categorical= list(data.select_dtypes(include='object').columns)
print('Total number of columns are:', total)
print('categorical columns are:', categorical)
print('numerical columns are:', numerical)
```

    Total number of columns are: 16
    categorical columns are: ['name', 'host_name', 'neighbourhood_group', 'neighbourhood', 'room_type', 'last_review']
    numerical columns are: ['id', 'host_id', 'latitude', 'longitude', 'price', 'minimum_nights', 'number_of_reviews', 'reviews_per_month', 'calculated_host_listings_count', 'availability_365']
    


```python
#number of unique values for each feature
data.nunique()
```




    id                                48895
    name                              47905
    host_id                           37457
    host_name                         11452
    neighbourhood_group                   5
    neighbourhood                       221
    latitude                          19048
    longitude                         14718
    room_type                             3
    price                               674
    minimum_nights                      109
    number_of_reviews                   394
    last_review                        1764
    reviews_per_month                   937
    calculated_host_listings_count       47
    availability_365                    366
    dtype: int64




```python
#missing value analysis
data_missing=data.isna().sum()
df=data_missing/len(data)*100
print('Percentage missing values')
df
```

    Percentage missing values
    




    id                                 0.000000
    name                               0.032723
    host_id                            0.000000
    host_name                          0.042949
    neighbourhood_group                0.000000
    neighbourhood                      0.000000
    latitude                           0.000000
    longitude                          0.000000
    room_type                          0.000000
    price                              0.000000
    minimum_nights                     0.000000
    number_of_reviews                  0.000000
    last_review                       20.558339
    reviews_per_month                 20.558339
    calculated_host_listings_count     0.000000
    availability_365                   0.000000
    dtype: float64




```python
#clean the dataset, by replacing numerical values by mean and dropping na values for categorical variables
data[:5]
dataCleaned=data.fillna(0)
```


```python
#uni-variate analysis to understand distribution of each numerical feature
fig, ax = plt.subplots(len(numerical), figsize=(16,12))
for i, col_val in enumerate(numerical):
    sns.distplot(dataCleaned[col_val], hist=True, ax=ax[i])
    ax[i].set_title('Freq dist '+col_val, fontsize=10)
plt.show()
```

    C:\Users\Shreya Kar\Anaconda3\lib\site-packages\scipy\stats\stats.py:1713: FutureWarning: Using a non-tuple sequence for multidimensional indexing is deprecated; use `arr[tuple(seq)]` instead of `arr[seq]`. In the future this will be interpreted as an array index, `arr[np.array(seq)]`, which will result either in an error or a different result.
      return np.add.reduce(sorted[indexer] * weights, axis=axis) / sumval
    


![png](output_9_1.png)



```python
#univariate analysis for categorical variables with limited distinct values
categoricalColums=['neighbourhood_group', 'neighbourhood', 'room_type', 'last_review']
print(dataCleaned['neighbourhood_group'].value_counts().plot.bar(title="dist"))
# print(data['room_type'].value_counts().plot.bar(title="dist"))
# print(data['last_review'].value_counts().plot.bar(title="dist"))
```

    AxesSubplot(0.125,0.125;0.775x0.755)
    


![png](output_10_1.png)



```python
#bivariate analysis
df=dataCleaned[numerical]
sns.pairplot(df)
```




    <seaborn.axisgrid.PairGrid at 0x26db05ad9b0>




![png](output_11_1.png)



```python
#correlation matrix
f, ax = plt.subplots(figsize=(10, 8))
corr = dataCleaned.corr()
sns.heatmap(corr,
            xticklabels=corr.columns.values,
            yticklabels=corr.columns.values)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x26dc110b438>




![png](output_12_1.png)



```python
#outlier analysis
fig, ax = plt.subplots(len(numerical), figsize=(8,40))

for i, col_val in enumerate(numerical):

    sns.boxplot(y=dataCleaned[col_val], ax=ax[i])
    ax[i].set_title('Box plot - {}'.format(col_val), fontsize=10)
    ax[i].set_xlabel(col_val, fontsize=8)

plt.show()
```


![png](output_13_0.png)

